#include<lpc21xx.h>   //Includes LPC2148 register 

unsigned char GsmSendMsg(unsigned char *msgStr);
void DelayMs(unsigned int count);
void uart1Init(void);
void uart1Putch(unsigned char ch);
void Uart1PutS(unsigned char *Str);

int main(void)
{  
   Uart1Init();
   Uart1PutS("AT\r\n");
   DelayMs(500);
   Uart1PutS("ATE0\r\n");  //Turn echo off
   DelayMs(500);
   Uart1PutS("ATD8552982172;\r\n"); //replace xxxxxxxxxx with number to call
   DelayMs(20000);
   Uart1PutS("ATH0\r\n");      //disconnect call
   DelayMs(3000);
   GsmSendMsg("Welcome to PICT");
   while(1);
}

unsigned char GsmSendMsg(unsigned char *msgStr)
{
    Uart1PutS("AT+CMGF=1\r\n");//Send SMS: Select Text mode
    DelayMs(100);
    Uart1PutS("AT+CMGS=\"8552982172\"\r\n"); //Send SMS to mobile number
    DelayMs(100);  
    Uart1PutS(msgStr);
    DelayMs(100);  
    Uart1PutCh(0x1A);          //CNTL + Z
    DelayMs(3000); 
    return (1);
}

void DelayMs(unsigned int count) 
{
    volatile unsigned int j,k;
    for (j=0;j<count;j++) 
        for (k=0;k<6000;k++);
}



void uart1Init(void)      
{
    PINSEL0=0x00050000;// port 0 tx P0.8 and rx P0.9 
    U1LCR=0x83; //8bit data, no parity, 1 stop bit
    U1DLL=97;// 9600 baud rate @15Mhz Pclk
    U1LCR=0x03;// DLAB=0
  
}
void uart1Putch(unsigned char ch)
{
    U1THR=ch;    // Transmitter holding register
    while(!(U1LSR & 0x20));// wait still THR=0 
}

void Uart1PutS(unsigned char *Str)
{
int i=0;
while(Str[i]!='\0')
 {
   uart1Putch(Str[i]);
   i++;
 }
}