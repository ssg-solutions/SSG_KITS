# UART-LPC2148
Communicate PC and LPC2148 Microcontroller over Serial UART Interface.
