#include "system.h"
#include "demo.h"
#include "serial.h"

int main(void)
{
	//mpu_example();
	oled_example();
}
