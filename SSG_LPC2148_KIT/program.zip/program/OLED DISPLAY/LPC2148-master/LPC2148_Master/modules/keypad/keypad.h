#ifndef KEYPAD_H_
#define KEYPAD_H_

#define ROWS 		4
#define COLUMNS 4

uint8_t get_keypad_key(void);

#endif /* KEYPAD_H_ */

