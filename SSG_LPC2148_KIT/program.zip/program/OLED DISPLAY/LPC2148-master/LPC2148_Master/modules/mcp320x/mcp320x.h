#ifndef MCP320X_H_
#define	MCP320X_H_

uint16_t read_mcp320x(uint8_t channel);

#endif

