#ifndef DELAY_H_
#define	DELAY_H_

void delay_ms(unsigned int d);
void delay_us(unsigned int d);

#endif
