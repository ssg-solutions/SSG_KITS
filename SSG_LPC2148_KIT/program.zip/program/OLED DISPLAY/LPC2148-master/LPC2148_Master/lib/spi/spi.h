#ifndef SPI_H_
#define SPI_H_

void spi_init (void);
uint8_t spi_data(uint8_t cmd);

#endif /* SPI_H_ */
