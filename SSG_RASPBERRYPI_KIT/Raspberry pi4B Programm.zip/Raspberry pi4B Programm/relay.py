# CONNECT BOARD 16 OR GPIO 23 WITH RELAY SIG
import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
relay=24
GPIO.setup(relay,GPIO.OUT)
while True:
    GPIO.output(relay,GPIO.HIGH)
    print("RELAY HIGH")
    time.sleep(0.5)
    GPIO.output(relay,GPIO.LOW)
    print("RELAY LOW")
    time.sleep(0.5)
    
